package com.voicefun.changer

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {
    private val effects = listOf("Normal", "Chipmunk", "Deep", "Robot", "Echo")
    private val engine get() = VoiceService.engine
    private lateinit var liveBtn: Button
    private lateinit var recBtn: Button
    private var recording = false
    private var afterPerm: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(24), px(48), px(24), px(24))
            setBackgroundColor(Color.parseColor("#101418"))
        }
        fun label(t: String, size: Float = 16f) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, px(12), 0, px(6))
        }

        root.addView(label("🎙 Voice Changer", 26f))

        val gainLabel = label("Volume boost: ${(engine.gain * 100).toInt()}%")
        root.addView(gainLabel)
        root.addView(SeekBar(this).apply {
            max = 200
            progress = (engine.gain * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    engine.gain = p / 100f
                    gainLabel.text = "Volume boost: $p%"
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })

        root.addView(label("Effect"))
        val group = RadioGroup(this)
        effects.forEachIndexed { i, name ->
            group.addView(RadioButton(this).apply {
                id = i + 1000; text = name; setTextColor(Color.WHITE)
                isChecked = i == engine.effect
            })
        }
        group.setOnCheckedChangeListener { _, id -> engine.effect = id - 1000 }
        root.addView(group)

        liveBtn = Button(this).apply { textSize = 16f; setOnClickListener { liveToggle() } }
        recBtn = Button(this).apply { textSize = 16f; setOnClickListener { recToggle() } }
        root.addView(liveBtn, LinearLayout.LayoutParams(-1, px(60)).apply { topMargin = px(24) })
        root.addView(recBtn, LinearLayout.LayoutParams(-1, px(60)).apply { topMargin = px(12) })

        root.addView(TextView(this).apply {
            text = "LIVE: speaker/Bluetooth se bajta hai (dusre phone ya headphone ke saath use karo).\n\n" +
                "RECORD: voice effect + boost ke saath record karke seedha kisi bhi app " +
                "(Telegram, WhatsApp, Instagram, Discord...) me share karo."
            setTextColor(Color.GRAY)
            setPadding(0, px(20), 0, 0)
        })

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        liveBtn.text = if (engine.running && !recording) "STOP LIVE" else "START LIVE"
        recBtn.text = if (recording) "STOP & SHARE" else "RECORD VOICE"
    }

    private fun withPerms(action: () -> Unit) {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) action() else {
            afterPerm = action
            requestPermissions(need.toTypedArray(), 1)
        }
    }

    private fun begin() {
        startForegroundService(Intent(this, VoiceService::class.java))
        liveBtn.postDelayed({ refresh() }, 500)
    }

    private fun end() {
        stopService(Intent(this, VoiceService::class.java))
        liveBtn.postDelayed({ refresh() }, 300)
    }

    private fun liveToggle() {
        if (recording) return
        if (engine.running) end() else withPerms {
            engine.monitor = true
            engine.capture = null
            begin()
        }
    }

    private fun recToggle() {
        if (recording) { finishRecording(); return }
        if (engine.running) { Toast.makeText(this, "Pehle LIVE band karo", Toast.LENGTH_SHORT).show(); return }
        withPerms {
            engine.monitor = false
            engine.capture = ByteArrayOutputStream()
            recording = true
            begin()
            refresh()
        }
    }

    private fun finishRecording() {
        val cap = engine.capture
        engine.capture = null
        recording = false
        end()
        engine.monitor = true
        refresh()
        val pcm = cap?.toByteArray() ?: return
        if (pcm.isEmpty()) return
        val uri = saveWav(pcm) ?: run {
            Toast.makeText(this, "Save nahi hua", Toast.LENGTH_SHORT).show(); return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "audio/x-wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Voice share karo"))
    }

    private fun saveWav(pcm: ByteArray): android.net.Uri? {
        val sr = 44100
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray()); putInt(36 + pcm.size); put("WAVE".toByteArray())
            put("fmt ".toByteArray()); putInt(16); putShort(1); putShort(1)
            putInt(sr); putInt(sr * 2); putShort(2); putShort(16)
            put("data".toByteArray()); putInt(pcm.size)
        }.array()
        val v = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, "voice_${System.currentTimeMillis()}.wav")
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/x-wav")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/VoiceChanger")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        contentResolver.openOutputStream(uri)?.use { it.write(h); it.write(pcm) } ?: return null
        v.clear(); v.put(MediaStore.Audio.Media.IS_PENDING, 0)
        contentResolver.update(uri, v, null, null)
        return uri
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            afterPerm?.invoke()
        afterPerm = null
    }

    override fun onResume() { super.onResume(); refresh() }
}
