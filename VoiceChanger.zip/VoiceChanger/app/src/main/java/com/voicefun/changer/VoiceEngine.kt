package com.voicefun.changer

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tanh

/** Real-time pitch shifter (dual-tap delay line, constant latency). */
class PitchShifter(private val ratio: Float) {
    private val w = 2048
    private val mask = 8191
    private val buf = FloatArray(8192)
    private var pos = 0
    private var phase = 0f
    private val pi = PI.toFloat()

    private fun read(delay: Float): Float {
        val p = pos - delay
        val i = floor(p).toInt()
        val f = p - i
        val a = buf[i and mask]
        val b = buf[(i + 1) and mask]
        return a + (b - a) * f
    }

    fun process(x: Float): Float {
        buf[pos and mask] = x
        val q = (phase + 0.5f) % 1f
        val y = read(phase * w) * sin(pi * phase) + read(q * w) * sin(pi * q)
        phase += (1f - ratio) / w
        if (phase < 0f) phase += 1f
        if (phase >= 1f) phase -= 1f
        pos++
        return y
    }
}

class VoiceEngine {
    /** 0f..2f  (0%..200%) */
    @Volatile var gain = 1f
    /** 0 Normal, 1 Chipmunk, 2 Deep, 3 Robot, 4 Echo */
    @Volatile var effect = 0
    /** false = speaker pe nahi bajega (sirf record) */
    @Volatile var monitor = true
    /** not null = processed audio yahan capture hoga (16-bit PCM, 44100 Hz mono) */
    @Volatile var capture: java.io.ByteArrayOutputStream? = null
    @Volatile var running = false
        private set
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread { loop() }.also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun stop() {
        running = false
        thread?.join(700)
        thread = null
    }

    @Suppress("MissingPermission")
    private fun loop() {
        val sr = 44100
        val minIn = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)

        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, sr,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minIn * 2
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(minOut * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()

        val chip = PitchShifter(1.6f)
        val deep = PitchShifter(0.65f)
        val echoBuf = FloatArray(sr / 4)
        var echoIdx = 0
        var ringPhase = 0f
        val ringStep = (2 * PI * 50 / sr).toFloat()

        val buf = ShortArray(1024)
        rec.startRecording()
        track.play()

        while (running) {
            val n = rec.read(buf, 0, buf.size)
            if (n <= 0) continue
            val g = gain
            val fx = effect
            for (i in 0 until n) {
                val x = buf[i] / 32768f
                var y = when (fx) {
                    1 -> chip.process(x)
                    2 -> deep.process(x)
                    3 -> {
                        ringPhase += ringStep
                        if (ringPhase > 2 * PI.toFloat()) ringPhase -= 2 * PI.toFloat()
                        x * sin(ringPhase) * 1.5f
                    }
                    4 -> {
                        val d = echoBuf[echoIdx]
                        val out = x + d * 0.45f
                        echoBuf[echoIdx] = out
                        echoIdx = (echoIdx + 1) % echoBuf.size
                        out
                    }
                    else -> x
                }
                y *= g
                y = if (g > 1f) tanh(y) else y.coerceIn(-1f, 1f)
                buf[i] = (y * 32767f).toInt().toShort()
            }
            val cap = capture
            if (cap != null) {
                val bb = ByteArray(n * 2)
                for (i in 0 until n) {
                    bb[2 * i] = (buf[i].toInt() and 0xff).toByte()
                    bb[2 * i + 1] = ((buf[i].toInt() shr 8) and 0xff).toByte()
                }
                cap.write(bb, 0, n * 2)
            }
            if (monitor) track.write(buf, 0, n)
        }

        rec.stop(); rec.release()
        track.stop(); track.release()
    }
}
